# import pymysql
#
# db = pymysql.connect(host='cdb-73f66stc.bj.tencentcdb.com',port=10257,user='root',password='123xiang',database='project',charset='utf8')
# cursor = db.cursor()
# cursor.execute("select * from user")
# data = cursor.fetchall()
# print(data)


# word="I'm a boby, I'm a girl. When it is true, it is ture. thit are cats, the red is red."
# word=word.replace(',','').replace('.','')
# word=word.split()
# print(word)
# setword=set(word)
# for i in setword:
#     count=word.count(i)
#     print(i,'出现次数：',count)

import time
strtime = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime())
print(strtime)