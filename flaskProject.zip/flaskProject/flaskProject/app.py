from flask import Flask, render_template, redirect, url_for
import pymysql
from flask import request
import time
import re

app = Flask(__name__)

temp = 0

@app.route('/')
def hello_world():
    #获取当前文章列表
    db = pymysql.connect(host='cdb-73f66stc.bj.tencentcdb.com', port=10257, user='root', password='123xiang',database='wordfriend', charset='utf8')
    cursor = db.cursor()
    sql = 'select * from page'
    cursor.execute(sql)
    data = cursor.fetchall()
    sql = 'select * from word order by times desc '
    cursor.execute(sql)
    wordlist = cursor.fetchall()

    return render_template("index.html",pagelist=data,wordlist=wordlist)


@app.route('/submitpage',methods=['POST'])
def submitPage():
    #获取form表单里的数据
    pagename = request.form['pagename']
    pagecontent = request.form['page']
    strtime = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())

    #连接数据库，使用腾讯云Mysql
    db = pymysql.connect(host='cdb-73f66stc.bj.tencentcdb.com',port=10257,user='root',password='123xiang',database='wordfriend',charset='utf8')
    cursor = db.cursor()
    #插入新文章
    sql = 'insert into page(pagename,pagecontent,time) VALUES (%s,%s,%s)'
    cursor.execute(sql,(pagename,pagecontent,strtime))
    db.commit()

    #计算单词出现数字
    blacklist = '1234567890!@#$%^&*()_+,./;\'\"\\:<>?[]|}{'
    for i in blacklist:
        pagecontent = pagecontent.replace(i, ' ')
        pagecontent = pagecontent.lower()
        pagecontent = re.sub(u"([^\u0061-\u007a])","",pagecontent)
    word = pagecontent
    word = word.split()
    print(word)
    setword = set(word)
    for i in setword:
        count = word.count(i)
        # print(i, count)
        #检索数据库中是否有该字段
        sql = 'select * from word where word = %s'
        cursor.execute(sql,i)
        data = cursor.fetchall()
        print(data)
        #如果没有该单词，插入新记录
        if data == ():
            sql = 'insert into word(word,times,unfamiliarity) VALUES (%s,%s,%s)'
            cursor.execute(sql, (i, count, 0))
            db.commit()
        #如果有，则在原有基础上增加次数
        else:
            num = data[0][2]+count
            sql = 'update word set times = %s where word = %s'
            cursor.execute(sql, (num,i))
            db.commit()
    db.close()
    return redirect(url_for('hello_world'))


@app.route('/page/<pageid>')
def page(pageid):
    db = pymysql.connect(host='cdb-73f66stc.bj.tencentcdb.com', port=10257, user='root', password='123xiang',
                         database='wordfriend', charset='utf8')
    cursor = db.cursor()
    sql = 'select * from page where id = %s'
    cursor.execute(sql,pageid)
    data = cursor.fetchall()
    wordlist = []
    words=[]
    pagecontent = data[0][2]
    blacklist = '1234567890!@#$%^&*()_+,./;\'\"\\:<>?[]|}{'
    for i in blacklist:
        pagecontent = pagecontent.replace(i, ' ')
        pagecontent = pagecontent.lower()
        pagecontent = re.sub(u"([^\u0061-\u007a])","",pagecontent)
    word = pagecontent
    word = word.split()
    setword = set(word)
    for i in setword:
        count = word.count(i)
        #存单词和次数
        wordlist.append([i,count])
        #只存单词
        words.append(i)


    sql = 'select * from word order by times desc '
    cursor.execute(sql)
    allwords = cursor.fetchall()
    print(allwords)
    sorted(wordlist, key=lambda wordlist: wordlist[1], reverse=True)

    all=[]
    #判断单词是否已存在,传入前端，当为0时不存在，为1已存在
    for i in allwords:
        if i[1] in words:
            all.append([i[0],i[1],i[2],i[3],1])
        else:
            all.append([i[0], i[1], i[2], i[3], 0])

    return render_template('page.html',pageid=pageid,page=data[0],wordlist=wordlist,allwords=allwords,all=all)


@app.route('/unfamiliar',methods=['POST'])
def unfamiliar():
    x = request.form['x']
    global temp
    temp = x
    if int(x) not in [0,1,2,3]:
        return "只能输入0-3的整数"
    db = pymysql.connect(host='cdb-73f66stc.bj.tencentcdb.com', port=10257, user='root', password='123xiang',
                         database='wordfriend', charset='utf8')
    cursor = db.cursor()
    sql = 'select * from word where unfamiliarity >= %s order by unfamiliarity desc '
    cursor.execute(sql,x)
    data = cursor.fetchall()
    return render_template('unfamiliar.html',data=data)


@app.route('/update/<id>',methods=['POST'])
def update(id):
    i = request.form['i']
    if int(i) not in [0,1,2,3]:
        return "只能输入0-3的整数"
    db = pymysql.connect(host='cdb-73f66stc.bj.tencentcdb.com', port=10257, user='root', password='123xiang',
                         database='wordfriend', charset='utf8')
    cursor = db.cursor()
    sql = 'update word set unfamiliarity = %s where id = %s'
    cursor.execute(sql,(i,id))
    db.commit()
    db.close()
    return redirect(url_for('hello_world'))


@app.route('/update2/<id>',methods=['POST'])
def update2(id):
    global temp
    i = request.form['i']
    if int(i) not in [0,1,2,3]:
        return "只能输入0-3的整数"
    db = pymysql.connect(host='cdb-73f66stc.bj.tencentcdb.com', port=10257, user='root', password='123xiang',
                         database='wordfriend', charset='utf8')
    cursor = db.cursor()
    sql = 'update word set unfamiliarity = %s where id = %s'
    cursor.execute(sql,(i,id))
    sql = 'select * from word where unfamiliarity >= %s order by unfamiliarity desc '
    cursor.execute(sql,temp)
    data = cursor.fetchall()
    db.commit()
    db.close()
    return render_template('unfamiliar.html',data=data)



if __name__ == '__main__':
    app.run()


